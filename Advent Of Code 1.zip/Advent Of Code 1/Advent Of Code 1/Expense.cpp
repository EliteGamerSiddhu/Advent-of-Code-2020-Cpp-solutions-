/*#include <iostream>
#include <fstream>
#include <string>

int main() {
	int a[200];
	int count = 0;
	int line = 0;
	int current = 0;
	int fnumber = 0;
	int snumber = 0;
	int result;
	std::string lol;
	std::ifstream myfile("Input.txt");
	if (myfile.is_open()) {
		while (getline(myfile, lol)) {
			int i = stoi(lol);
			a[count] = i;
			count++;
		}
	}
	myfile.close();

	while (fnumber + snumber != 2020) {
		fnumber = a[line];
		snumber = a[current];
	 while ((fnumber + snumber != 2020) && (current != count))
		{
			snumber = a[current];
			current++;
		}
	 line++;
	 current = 0;
	}
	std::cout << "The numbers are " << fnumber << " and " << snumber << std::endl;
	result = fnumber * snumber;
	std::cout << "The product of the numbers is " << result;
	return 0;
} */