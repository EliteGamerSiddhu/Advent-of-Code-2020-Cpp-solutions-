#include <iostream>
#include <fstream>
#include <string>

int main() {
	int a[200];
	int count = 0;
	int line = 0;
	int current = 0;
	int fnumber = 0;
	int snumber = 0;
	int tnumber = 0;
	int scurrent = 0;
	int result;
	std::string lol;
	std::ifstream myfile("Input.txt");
	if (myfile.is_open()) {
		while (getline(myfile, lol)) {
			int i = stoi(lol);
			a[count] = i;
			count++;
		}
	}
	myfile.close();

	while (fnumber + snumber + tnumber != 2020) {
		fnumber = a[line];
		while ((fnumber + snumber + tnumber != 2020) && (current != count + 1))
		{
			snumber = a[current];
			while ((fnumber + snumber + tnumber != 2020) && (scurrent != count + 1)) {
				tnumber = a[scurrent];
				scurrent++;
			}
			current++;
			scurrent = 0;
		}
		line++;
		current = 0;
	}
	std::cout << "The numbers are " << fnumber << " and " << snumber << " and " << tnumber << std::endl;
	result = fnumber * snumber * tnumber;
	std::cout << "The product of the numbers is " << result;
	return 0;
}